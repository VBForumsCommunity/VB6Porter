Advanced Microsoft Visual Basics (second edition)
Chapter 7. Page 275.

"C:\Program Files (x86)\Microsoft Visual Studio\VB98\VB6.EXE" /make "C:\VBlibrary\Project1.vbp" /out "C:\VBlibrary\errStatus.txt" /outdir "C:\VBlibrary\"

C2.EXE compiles the object files, then the LINK.EXE links them together for the final output.
Use Visual Basic as normal and it will hook the compilation process to the files renamed as C3.EXE and L1NK.EXE.
The output file is written to C2.txt and LINK.txt.
It will capture the params that were passed to invoke the compliation, depending on your project's properties.

A typical command line compilation for C2 looks like this:
C2 -il C:\Windows\Temp\VB603389 -f Form1 -W 3 -Gy -G5 -Gs4096 -dos -Z1 -FoC:\Temp\Form1.OBJ -QIfdiv -ML -basic
Undocumented. Used for a C program to name intermediate language files.
il C:\Windows\Temp\VB603389
Temp files generated;VB603389GL,VB603389SY,VB603389EX,VB603389IN,VB603389DB

The input file to be compiled.
-f Form1
Warning level 3
-W 3
Enable function level linking See command line: CL.EXE /? for Gx options below
-Gy
Optimize for pentium
-G5
Turn off stack probes. When size stack is required for local variables, the stack proble is activated. Probe checks for enough space required for passed params and local variables is available on the stack before allocating it.
-Gs4096
Use for a C program.
-dos
Remove default library name from OBJ file
-Z1
Name of output file
-FoC:\Temp\Form1.OBJ
Perform pentium FDIV erratum fix
-QIfdiv
Create a single-threaded executable file. Places the library name LIBC.LIB in the object file so that the linker will use LIBC.LIB to resolve external symbols.
-ML
Undocumented a new flag for Visual Basic compilation
-basic
Command line compilation switches for LINk look like this:
Form OBJ file
C:\Temp\Form1.OBJ
Module OBJ file
C:\Temp\Module1.OBJ
Project OBJ file
C:\Temp\Project1.OBJ
Library of Visual Basic OBJs.
C:\Program Files (x86)\Microsoft Visual Studio\VB98\VBAEXE6.LIB
Sets the starting address for an executable file or DLL. This entry point is in your Project1.OBJ file.
/ENTRY:__vbaS
The output file exe
/OUT:C:\Temp\Project1.exe
Sets a base address for the program.
/BASE:0x400000
Tells the OS how to run the .EXE (CONSOLE, WINDOWS, NATIVE, POSIX)
/SUBSYSTEM:WINDOWS,4.0
Tells the linker to put a version number in the header of the executable file or DLL.
/VERSION:1.0
Creates debug info for the exe or DLL, and places it in to the PDB(program database)
/DEBUG
Generates debugging info in one of 3 ways. (Microsoft format, COFF, both) COFF (common object file format)
/DEBUGTYPE:{CV|COFF|BOTH}
Specifies whether incremental linking is required.
/INCREMENTAL:NO
Excludes unreferenced packaged functions(using-Gy) from the exe.
/OPT:REF
Combines the first section with the second section,. If the second section does not exist, LINK renames the section "from" as "to". The /MERGE option is most useful for creating VxD's and overriding compiler generated section names.
/MERGE:from=to
Ignores certain warnings (defined in LINK.ERR). 4078 means that LINK found two or more sections that have the same name but different attributes.
/IGNORE:4078